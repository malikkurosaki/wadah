# Probus chatbot assistant FAQ

nama product : probus chatbot assistant

creator : probussystem

__disclaimer__

probus assistan adalah pengemmbangan kecerdasan buatan , yang diperuntukkan 
untuk mempermudah kegiatan customer , sebagai faktor pendukung beberaap product 
probussystem

__Petunjuk Penggunaan__

- anda bisa langsung menekan tombol icon `mic` pada sebelah kanan bawah untuk memulai
percakapan dengan probus saaisatant

- astau anda bisa mengetik sesuatu yang ingin anda tanyakan


__pertanyaan umum__

secara garis besar probus assistant masih dalam tahap pengembangan 
maun sudah mampu untuk mengimbangi beberapa pertanyaan anda 

__kata kunci__

untuk pencarian customer anda bisa mengunakan format percakapan 
baik ketik maupun pembicaraan ( penggunaan microfon ) sebagai berikut

`[apa saja][atas nama][kata kunci]`

_lcontoh :_ 

 `tolong carikan [atas nama][kunci = / ahmad / dani / fitri /tugek / dll]`
 
 ``` java
tolong carikan atas nama agus 
```

__kemampuan lainya__

salah satu kemampuan probus assistant anda bisa memerintahkannya untuk
membuka aplikasi yang sudah terinstal pada handphone anda

_contoh_

```java
probus tolong buka whatsapp
```

