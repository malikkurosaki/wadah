# BEST WA HUNTER

---

            author : malik kurosaki
            phone : wa 081338929722
            company : best media learning denpasar bali
            penanggung jawab : yogi yanuar



_best media learning mepersembahkan_ __BEST WA HUNTER__

konsep dasar dari aplikasi ini adalah mencari teman sebanyak banyaknya di whatsapp
yang pada dasarnya kita harus menginputnya satu persatu jika ingin melakukannya
dengan aplikasi ini kita bisa mencari teman sebanyak banyaknya pada whatsapp tanpa harus
ribet memasukkan satu persatu nomor , karena aplikasi ini yang langsung akan mengerjakannya

#### contoh pemakaian
- pertama pilih kode negara yang ingin dijadikan target secara default
sudah ter set pada negara indonesia , namun anda bisa mengubahnya sesuka anda

- lalu tahapan kedua anda memasukkan nomor telpon sesuai keinginnan anda > anda bisa memasukkan nomor anda sendiri > jika ingin sesuai wilayah
anda bisa memasukkan kode area dkiikuti dengan nomor telpon
__contoh__: 081338929722 maka anda memasukkannya tanpa nol didepan __jadi__: 81338929722


- lanjut masukkan nilai jumbah nomor yang ingin anda inginkan semisal 50 atau 100 __inf0__ : khusus angka diatas
100 adalah untuk yang versi premium , bisa sampai ribuan nomor yang bisa diproduksi

- selanjutnya tekan tombol start , maka aplikasi akan mulai berkerja mencarikan nomor nomor yang aktif wanya ,
jika telah didapatkan anda akan langsung ditunjukkan pada aplikasi wa mana saja nomor nomor yang telah anda dapatkan


- untuk membersihkan area kerja anda bisa menekan tombol clean


```
aplikasi ini masih dalam tahap pengembangan , adapun terjadi kendala
ataupun error anda bisa langsung menghubungi developer pada nomer wa 081338929722

setiap penyalahgunaan aplikasi murni menjadi tanggung jawab pemakai , kami selaku pengembang
hanya menyediakan alat untuk mempermudah aktivitas anda
```



##### akhir kata selaku pengembang kami ucapkan banyak banyak terimakasih , tanpa support dan dukungan anda kami tidak akan mungki berkarya

_mohon fitback dan dukungan serta komentar pada kolom komentar di playstore_

untuk kritik dan saran anda bisa langsung melayangkan ke : bestmedialearning@gmail.com kami akan sangat senang mendengar masukan dari anda


## BONUSSSS !!!
kode wilayah seluruh indonesia

- Kode Area HLR Telkomsel JABODETABEK – BANTEN:
Jakarta, Bogor, Sukabumi, Karawang, Serang
08111, 08118, 08119, 081210, 081211, 081212, 081213, 081218, 081219, 08128, 081298, 081299, 085210, 085213, 085214, 085215, 085216, 085217, 085218, 085219, 08528, 082110, 082111, 082112, 082113, 082114


- Kode Area HLR Telkomsel JABAR :
Bandung, Cirebon, Cianjur, Tasikmalaya
081120, 081121, 081122, 081123, 081124, 081214, 081220, 081221, 081222, 081223, 081224, 081312, 081313, 081320, 081321, 081322, 081323, 081324, 081394, 081395, 085220, 085221, 085222, 085223, 085224, 085294, 085295, 085320, 085321, 085322, 085323, 085324, 082115, 082116, 082117, 082118, 082119, 08212, 082130, 082131, 082132

- Kode Area HLR Telkomsel DIY / JATENG :
Semarang, Solo, Purwekerto, Yogyakarta
081125, 081126, 081127, 081128, 081129, 081215, 081225, 081226, 081227, 081228, 081229, 081325, 081326, 081327, 081328, 081329, 081390, 081391, 081392, 081393, 085225, 085226, 085227, 085228, 085229, 085290, 085291, 085292, 085293, 085325, 085326, 085327, 085328, 085329, 082133, 082134, 082135, 082136, 082137, 082138

- Kode Area HLR Telkomsel JATIM :
Surabaya, Malang, Madiun, Jember
081130, 081131, 081132, 081133, 081134, 081135, 081136, 081137, 081216, 081217, 081230, 081231, 081232, 081233, 081234, 081235, 081249, 081252, 081259, 081330, 081331,081332, 081333, 081334, 081335, 081336, 081357, 081358, 081359, 085230, 085231, 085232, 085233, 085234, 085235, 085236, 085257, 085258, 085259, 085330, 085331, 085332, 085333, 085334, 085335, 085336, 082139, 082140, 082141, 082142, 082143


- Kode Area HLR Telkomsel BALINUSRA :
Denpasar, Sumbawa, Kupang, Mataram
081138, 081139, 081236, 081237, 081238, 081239, 081246, 081337, 081338, 081339, 081253, 085237,085238, 085239, 085253, 085337, 085338, 085339, 082144, 082145, 082146, 082147

- Kode Area HLR Telkomsel KALIMANTAN :
Banjarmasin, Samarinda, Palangkaraya, Pontianak, Balikpapan
08115, 081250, 081251, 081253, 081254, 081255, 081256, 081257, 081258, 081345, 081346, 081347, 081348, 081349, 081350, 081351, 081352, 085245, 085246, 085247, 085248, 085249, 085250, 085251, 085252, 085345, 085346, 085347, 085348, 085349, 085350, 082148, 082149, 08215

- HLR Telkomsel SULAWESI:
Timika, Makassar, Manado, Palu, Kendari, Ternate
081140, 081141, 081142, 081143, 081144, 081145, 081146, 081147, 081149, 081240, 081241, 081242, 081243, 081244, 081245, 081247, 081340, 081341, 081342, 081343, 081354, 081355, 081356, 085240, 085241, 085242, 085243, 0852448, 0852449, 0852548, 0852549, 085298, 085340, 085341, 085342, 085343, 082187, 082188, 082189, 082190, 082191, 082192, 082193, 082194, 082195, 082196

- HLR Telkomsel MALUKU – PAPUA:
Jayapura, Merauke, Biak, Sorong, Manokwari, Jayapura
081148, 081248, 081344, 0852440, 0852441, 0852442, 0852443, 0852444, 0852445, 0852446, 0852447, 0852540, 0852541, 0852542, 0852543, 085344, 085354, 082169, 082170, 082171, 082172, 082172, 082174

- HLR Telkomsel SUMBAGUT:
Medan, Batam2, Aceh, Pekanbaru2, Padang, Pmt.Siantar, R.Prapat, P.Sidempuan, Sibolga, P.Brandan, Brastagi, Tj.Balai
08116, 08126, 081360, 081361, 081362, 081363, 081374, 081375, 081376, 0813770, 0813771, 0813772, 0813773, 0813774, 081378, 081396, 081397, 085260, 085261, 085262, 085263, 085270, 085274, 085275, 085276, 085277, 085296, 085297, 085360, 085361, 085362, 085363, 082160, 082161, 082162, 028163, 082164, 082165, 082166, 082167, 082168

- HLR Telkomsel SUMBAGSEL:
Batam1, Palembang, BatuRaja, P.Pinang, L.Linggau, M.Enim, Lampung, KotaBumi, Bengkulu, Dumai, Pekanbaru1, Jambi
08117, 08127, 081364, 081367, 081368, 081369, 081372, 081373, 0813775, 0813776, 0813777, 0813778, 0813779, 081379, 085264, 085265, 085266, 085267, 085268, 085269, 085271, 085272, 085273, 085278, 085279, 085365, 085366, 085367, 085368, 085369, 082175, 082176, 082177, 082178, 082179, 082180, 082181, 082182, 082183, 082184, 082185, 082186

- HLR /Prefix Area Sumatra Bagian Utara
  HLR INDOSAT
  SUMBAGUT
  Mentari
  081530,081531,081533,081534,0815360,0815361,0815362,0815363,08153640,08153641,08153642,08153646,08153647,08153648,0815366,0815367,0815368,0815369,081537,081630,081631,081633,081634,081636,081637,085830,085831,08583360,08583361,08583362,08583363,08583364,08583365,08583366,08583367,08583370,08583371,08583372,08583373,08583374,0858338,0858339,08583400,08583401,08583402,08583403,08583404,0858341,0858342,0858343,0858360,0858361,0858370,0858371,0858372,0858373,0858374,0858375,0858376,0858378,

## sisanya cari digoogle cwimmmm