# malik text to mp3

---

__indonesia language__

aplikasi ini saya buat dengan penuh kesadaran , adapun kekurangan ataupun
ketidak sempurnaan hanyalah semata mata , kesalahan dari saya
yang mungkin kurangnya pengetahuan dan secangkir kopi

`mengapa aplikasi ini dibuat..?`

awalnya dari keprihatinan banyaknya youtuber yang gagal hanya
karena tidak bisa ngoceh atau malu ngoceh , nah disitu saya punya ide
kalo mesin bisa ngoceh buat kita mengapa kita susah susah harus ngoceh

 dari fungsinya sudah jelas yaitu merubah text/tulisan menjadi suara berektensi mp3
 anda bisa mencampurnya  dengan video editor atau sejenisnya
 dan juga bisa dijadikan ringtone

 `bagaimana cara menggunakannya`

 setelah anda menginstalnya isi sebuah kalimat atau text pada kolom
 yang telah disediakan, lalu coba rubah speed dan ratenya , angka bisa dari `0.1++`    hanya angka dan jangan menggunakan koma ( , ) tapi titik ( . )
 silahkan anda berexperiment
 untuk mengesave jangan lupa berikan nama pada kolom yang telah disediakan
 pada awalnya anda akan diminta untuk memberikan permisi untuk membaca `external`
 atau `sd card` tekan lagi tombol save makan aplikasi akan membuatkan folder pada `maliktexttomp3/output/`
 selanjutnya tekan lagi untuk proses penyimpanan , anda bisa mengeceknya secara manual
 pada folder `maliktomp3/output/nama.mp3` selanjutnya anda bisa gunakan suka suka hati


 jika terjadi troble dan aplikasi tidak mau membuat folder secara otomatis
 anda bisa membuatnya secara manual

 __langkah langkah jika terjadi kendala__

 - pastikan anda telah memberikan ijin kepada aplikasi anda bisa mengeceknya
 secara manual pada > `phone setting` > `instaled application` > `malik text to mp3` > `permission` lalu centang cemua perijinan
 - pastikan filder telah dibuat secara otomatis jika perlu anda mengeceknya secara manual jika terjadi kegagalan dalam plenyimpanan
 check `sdcard/internal` > `maliktexttomp3` > `output`


__apakah saya bisa mengganti bahasa__

tentu saja bisa , aplikasi ini memngikuti bahasa yang ada pada handphone anda , anda bisa merubahnya pada
`setting phone` > `language and input` > pilih bahasa yang anda inginkan

__apakah saya bisa mengganti logat sesuai daerah saya..??__

bisa tapi membutuhkan beberapa trik salah satunya memberikan tanda baca ` . `  ` , `  ` ! ` ` ? ` dan lainnya
anda bisa berexperimen sesuka anda ,

_catatan_ : jika bahasa anda adalah bahasa indonesia , dan dalam text anda ada kalimat bahasa ingris
maka oleh mesin akan dibaca apa adanya , anda harus menyesuaikannya secara manual
**_contoh_** : `how are you` akan dibaca `ho a re y o u ` maka anda harus merubah kalimatnya sesuai dengan dealek bahasa indonesia **_contoh_** `ho ar yu` pada text > kareana bahasa pada ponsel anda
adalah bahasa indonesia maka mesin akan hanya membaca dalam bahasa endonesia

jika anda masih menemu kendala anda bisa menghubungi saya secara langsung

**wa 081338929722**
atau anda bisa mengetik pada google ` malikkurosaki ` nanti saya akan muncul


### english language
you just copy this text to google translate `bomm` you got english text