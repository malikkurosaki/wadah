package dev.malikkurosaki.probuspresto;

import com.google.gson.JsonObject;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ConnectDataUser {

    @GET("/api/user/poin")
    Call<List<JsonObject>> getUser();

    @GET("/api/user/poin/{id}")
    Call<List<JsonObject>> getUserPoin(@Path("id") String nama);

    @GET("/api/user/email/{id}")
    Call<List<JsonObject>> getEmail(@Path("id") String email);
}
