package dev.malikkurosaki.probuspresto;

import android.content.Intent;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ViewAnimator;
import android.widget.ViewSwitcher;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.hbb20.CountryCodePicker;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import es.dmoral.toasty.Toasty;

public class MainActivity extends AppCompatActivity {

    private EditText loginNumber;
    private Button loginBtn;
    private EditText loginCode;
    private TextView loginTime;
    private Button loginVerBtn;
    private ViewAnimator container1;
    private CountryCodePicker negara;

    private FirebaseAuth auth;
    private FirebaseUser user;

    private String TAG = "-->";
    private String code;
    private String verivication;
    private PhoneAuthCredential credential;


    private int hitungMundur;
    private boolean bolehHitung;

    //phone nymber
    private String neg; // kode negara
    private String num; // nomer hp


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loginNumber = findViewById(R.id.loginNumber);
        loginBtn = findViewById(R.id.loginBtn);
        loginCode = findViewById(R.id.loginCode);
        loginTime = findViewById(R.id.loginTime);
        loginVerBtn = findViewById(R.id.loginVerBtn);
        container1 = findViewById(R.id.container1);
        negara = findViewById(R.id.loginNegara);

        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();






        /*if (user != null){

            if (user.getPhoneNumber()!=null){
                Map<String,String> paket = new HashMap<>();
                paket.put("num_hp",user.getPhoneNumber());
                Intent intent = new Intent(MainActivity.this,Main2Activity.class);
                intent.putExtra("ikut", (Serializable) paket);
                startActivity(intent);
                finish();
            }


        }else {
            Toasty.info(getApplicationContext(),"login first",Toasty.LENGTH_LONG).show();
            masuk();
        }
        container1.setDisplayedChild(0);


        // jika sudah dapet codenya
        loginVerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cod = loginCode.getText().toString().trim();
                if (TextUtils.isEmpty(cod)){
                    Toasty.warning(getApplicationContext(),"code not be empty please",Toasty.LENGTH_LONG).show();
                    return;
                }
                if (TextUtils.isEmpty(code)){
                    Toasty.warning(getApplicationContext(),"system transport error , please check your connection",Toasty.LENGTH_LONG).show();
                    return;
                }

                if (!code.equals(cod)){
                    Toasty.info(getApplicationContext(),"wrong code ",Toasty.LENGTH_LONG).show();
                    return;
                }

                Toasty.info(getApplicationContext(),"code is match , wait ...",Toasty.LENGTH_LONG).show();
                signInWithPhoneAuthCredential(credential);

            }
        });
    }


    private void masuk(){
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                neg = "+"+negara.getSelectedCountryCode();
                num = loginNumber.getText().toString();

                Log.i(TAG, "check nomor: "+neg+num);
                if (TextUtils.isEmpty(num)){
                    Toasty.error(getApplicationContext(),"phone number not be empty",Toasty.LENGTH_LONG).show();
                    return;
                }
                PhoneAuthProvider.getInstance().verifyPhoneNumber(
                        neg+num,        // Phone number to verify
                        60,                 // Timeout duration
                        TimeUnit.SECONDS,   // Unit of timeout
                        MainActivity.this,               // Activity (for callback binding)
                        mCallbacks);
                Log.i(TAG, "onClick: ke callback");

                //rubah tampilan untuk mencocokkan code
                container1.setDisplayedChild(1);
                nungguCode();
            }
        });
    }

    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {

            //hasil codenya
            code = phoneAuthCredential.getSmsCode();
            Toasty.info(getApplicationContext(),"the code has sent to your phone by sms",Toasty.LENGTH_LONG).show();

            // credential untuk masuk / login
            credential = PhoneAuthProvider.getCredential(verivication, code);

            //signInWithPhoneAuthCredential(credential);
            Log.i(TAG, "onVerificationCompleted: "+code);

        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            Log.i(TAG, "onVerificationFailed: "+e);
        }
        @Override
        public void onCodeSent(String verificationId, PhoneAuthProvider.ForceResendingToken token) {
            // The SMS verification code has been sent to the provided phone number, we
            // now need to ask the user to enter the code and then construct a credential
            // by combining the code with a verification ID.
            Log.d(TAG, "onCodeSent:" + verificationId);

            // Save verification ID and resending token so we can use them later
            verivication = verificationId;
            //mResendToken = token;

            // ...
        }
    };

    // func untuk login
    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        Log.i(TAG, "signInWithPhoneAuthCredential: mulai sigin");
        auth.signInWithCredential(credential)
                .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithCredential:success");

                            FirebaseUser user = task.getResult().getUser();


                            // pengalihan ke halaman utama
                            finish();
                            Intent intent = new Intent(MainActivity.this,Main2Activity.class);
                            intent.putExtra("num_hp", neg + num);
                            startActivity(new Intent(MainActivity.this,Main2Activity.class));


                        } else {
                            // Sign in failed, display a message and update the UI
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                                Log.i(TAG, "onComplete: gagal ");
                                Toasty.warning(getApplicationContext(),"check your connection",Toasty.LENGTH_LONG).show();
                            }
                        }
                    }
                });*/
    }

    public void nungguCode(){
        hitungMundur = 30;
        bolehHitung = true;
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (hitungMundur > 0){
                    hitungMundur--;
                    loginTime.setText("00:"+String.valueOf(hitungMundur));
                    handler.postDelayed(this,1000);
                }else {
                    bolehHitung = false;
                    loginTime.setText("00:00");
                    handler.removeCallbacks(this);
                    Toasty.info(getApplicationContext(),"Timesup",Toasty.LENGTH_LONG).show();
                }
            }
        },1000);

    }

    //signout
    public void signout(){
        FirebaseAuth.getInstance().signOut();

    }


    public void toas(String info){
        Toasty.info(getApplicationContext(),info,Toasty.LENGTH_LONG).show();
    }
}
