package dev.malikkurosaki.probuspresto;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.HashMap;
import java.util.Map;

import es.dmoral.toasty.Toasty;

public class Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);


        Intent intent = getIntent();
        Map<String,String> terima = (HashMap<String,String>)intent.getSerializableExtra("muatan");
        String layout = terima.get("layout");
        Toasty.normal(getApplicationContext(),layout,Toasty.LENGTH_LONG).show();
    }
}
