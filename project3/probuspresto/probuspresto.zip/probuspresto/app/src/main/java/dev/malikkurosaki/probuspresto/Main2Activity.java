package dev.malikkurosaki.probuspresto;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.ViewAnimator;
import android.widget.ViewSwitcher;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.ByteArrayOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import es.dmoral.toasty.Toasty;
import in.mayanknagwanshi.imagepicker.ImageSelectActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Main2Activity extends AppCompatActivity {

    private FirebaseAuth auth;
    private FirebaseUser user;

    private String nomerHp;
    private String TAG = "-->";

    private ViewAnimator container2;

    private EditText verEmail;
    private Button btnVerEmail;
    private Button iptSignup;
    private TextView uploadProgres;

    private ImageView edtProfileFoto;
    private ImageButton edtProfBtnFoto;
    private EditText edtProfUserName,edtProfEmail,edtProfPass,edtProfBrith,edtProfPhone;
    private Button edtProfBtnSave;
    private ProgressBar loading;
    private DatePicker edtAmbilTanggal;
    private Button edtDateFinis;
    private boolean sudahUpload = false;


    // <include layout="@layout/layout_include_edit_profile"/>
    // <include layout="@layout/layout_include_input_email"/>

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        final Intent intent = getIntent();
        Map<String,String> paket = (HashMap<String,String>)intent.getSerializableExtra("ikut");

        /*if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},200);
        }*/

        container2 = findViewById(R.id.container2);
        container2.setDisplayedChild(0);
        verEmail =  findViewById(R.id.ver_email);
        btnVerEmail = findViewById(R.id.btnVerEmail);

        //definisi edit profile
        edtProfileFoto = findViewById(R.id.edt_prof_foto);
        edtProfBtnFoto = findViewById(R.id.edt_prof_btn_foto);
        edtProfUserName = findViewById(R.id.edt_prof_user_name);
        edtProfEmail = findViewById(R.id.edt_prof_email);
        edtProfPass = findViewById(R.id.edt_prof_pass);
        edtProfBrith = findViewById(R.id.edt_prof_birth);
        edtProfPhone = findViewById(R.id.edt_prof_phone);
        edtProfBtnSave = findViewById(R.id.edt_prof_btn_save);
        loading = findViewById(R.id.edt_prof_loading_foto);
        iptSignup = findViewById(R.id.ipt_signup);
        uploadProgres = findViewById(R.id.edt_prof_up_prog);
        edtAmbilTanggal = findViewById(R.id.edt_ambil_tanggal);
        edtDateFinis = findViewById(R.id.edt_date_finis);

        loading.setVisibility(View.GONE);

        //define firebase
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();

        if (user != null){
            nomerHp = user.getPhoneNumber();
            edtProfPhone.setText(nomerHp);
            //todo : cek jika nomer hp cocok
            if (nomerHp.equals(String.valueOf(paket.get("num_hp")))){
                container2.setDisplayedChild(1);

                // todo : pencocokan email
                btnVerEmail.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final String emailVer = verEmail.getText().toString().trim();
                        if (TextUtils.isEmpty(emailVer)){
                            Toasty.warning(getApplicationContext(),"email not be empty",Toasty.LENGTH_LONG).show();
                            return;

                        }

                        Retrofit retrofit = new Retrofit.Builder()
                                .baseUrl("https://mypizz.herokuapp.com")
                                .addConverterFactory(GsonConverterFactory.create())
                                .build();
                        ConnectDataUser dataUser = retrofit.create(ConnectDataUser.class);
                        Call<List<JsonObject>> panggilEmail = dataUser.getEmail(emailVer);
                        panggilEmail.enqueue(new Callback<List<JsonObject>>() {
                            @Override
                            public void onResponse(Call<List<JsonObject>> call, Response<List<JsonObject>> response) {
                                List<JsonObject> emailList = response.body();
                                String eml = "";
                                String telp = "";
                                for (JsonObject em : emailList){
                                    eml = em.get("email").getAsString().trim();
                                    telp = em.get("telpon").getAsString().trim();
                                }

                                if(!emailVer.equals(eml)){
                                   Toasty.warning(getApplicationContext(),
                                           "your email is not detect on our sistem , signup please ",
                                           Toasty.LENGTH_LONG).show();
                                   return;
                                }
                                if (!nomerHp.equals(telp)){
                                    Toasty.warning(getApplicationContext(),
                                            "your phone number is not detect on our database , call maintener or create new one",
                                            Toasty.LENGTH_LONG).show();
                                    return;
                                }

                                Intent intent1 = new Intent(Main2Activity.this,Main3Activity.class);
                                Map<String,String> angkutan = new HashMap<>();
                                angkutan.put("layout","home");
                                intent1.putExtra("muatan", (Serializable) angkutan);
                                startActivity(intent1);
                                finish();
                            }

                            @Override
                            public void onFailure(Call<List<JsonObject>> call, Throwable t) {

                            }
                        });
                    }
                });



            }else {
                container2.setDisplayedChild(0);
            }
        }

        // todo : tombol signup
        iptSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                container2.setDisplayedChild(0);
            }
        });


        // todo : retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://mypizz.herokuapp.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        ConnectDataUser dataUser = retrofit.create(ConnectDataUser.class);

        Call<List<JsonObject>> panggil  = dataUser.getUser();
        panggil.enqueue(new Callback<List<JsonObject>>() {
            @Override
            public void onResponse(Call<List<JsonObject>> call, Response<List<JsonObject>> response) {
                if (!response.isSuccessful()){

                    Toasty.info(getApplicationContext(),"connection error",Toasty.LENGTH_LONG).show();
                    return;
                }

                List<JsonObject> ambil = response.body();
                for (JsonObject datanya : ambil){
                    JsonElement nama = datanya.get("nm_cus");

                    Log.i(TAG, "onResponse: "+nama.getAsString());
                }

            }

            @Override
            public void onFailure(Call<List<JsonObject>> call, Throwable t) {

            }
        });

        layout1();
        updateProfile();
    }

    public void layout1(){
        edtProfBtnFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loading.setVisibility(View.VISIBLE);
                Intent intent = new Intent(Main2Activity.this, ImageSelectActivity.class);
                intent.putExtra(ImageSelectActivity.FLAG_CAMERA,true);
                startActivityForResult(intent,123);
            }
        });
    }

    //todo : update profile
    public void updateProfile(){
        edtProfBrith.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                container2.setDisplayedChild(2);
            }
        });

        edtDateFinis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                container2.setDisplayedChild(0);
                String tanggal = edtAmbilTanggal.getDayOfMonth()+" "+edtAmbilTanggal.getMonth()+" "+edtAmbilTanggal.getYear();
                edtProfBrith.setText(tanggal);
            }
        });

        edtProfBtnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!sudahUpload){
                    Toasty.warning(getApplicationContext(),"upload your foto profile olso",Toasty.LENGTH_LONG).show();
                    return;
                }

                String userName = edtProfUserName.getText().toString().trim();
                String email = edtProfEmail.getText().toString().trim();
                String password = edtProfPass.getText().toString().trim();
                String birth = edtProfBrith.getText().toString().trim();
                String phon = edtProfPhone.getText().toString().trim();

                if (TextUtils.isEmpty(userName) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password) || TextUtils.isEmpty(birth) || TextUtils.isEmpty(phon)){
                    Toasty.warning(getApplicationContext(),"all field is not be empty , OK! ",Toasty.LENGTH_LONG).show();
                    return;
                }




            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 123){
            if (resultCode == RESULT_OK){

                //todo : proses upload gambar
                String filePath = data.getStringExtra(ImageSelectActivity.RESULT_FILE_PATH);
                Bitmap selectedImage = BitmapFactory.decodeFile(filePath);
                edtProfileFoto.setImageBitmap(selectedImage);
                edtProfBtnFoto.setVisibility(View.GONE);

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                selectedImage.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] bytes = baos.toByteArray();

                FirebaseStorage storage = FirebaseStorage.getInstance();
                final StorageReference reference = storage.getReference().child(nomerHp+"/profile.png");
                final UploadTask uploadTask = reference.putBytes(bytes);
                uploadTask.addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                        uploadProgres.setVisibility(View.VISIBLE);
                        String prog = (int) Math.ceil((100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount()) +"%";
                        uploadProgres.setText(prog);
                    }
                }).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if (task.isSuccessful()){
                            DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
                            Map<String,String> foto = new HashMap<>();
                            foto.put("foto", nomerHp + "/profile.png");
                            ref.child("user").child("profile").child("foto").setValue(foto).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    sudahUpload = true;
                                    loading.setVisibility(View.GONE);
                                    uploadProgres.setVisibility(View.GONE);
                                }
                            });
                        }
                    }
                });

            }else {
                loading.setVisibility(View.GONE);
                Toasty.normal(getApplicationContext(),"from camera only",Toasty.LENGTH_LONG).show();
                container2.setDisplayedChild(0);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 200){
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Toasty.normal(getApplicationContext(),"permission has granted",Toasty.LENGTH_LONG).show();
            }
        }
    }
}
